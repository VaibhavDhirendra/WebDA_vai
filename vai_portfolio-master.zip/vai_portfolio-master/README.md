# collapse-portfolio

## Project

***EN:*** This project is a colorful single page portfolio with a collapsing effect on your navigation that shows information about a web developer. It was created during the Bootstrap 4.

## Technologies

This project was developed with the following technologies:

- HTML
- CSS
- Bootstrap
- JQuery
***
 
## Preview
![preview](preview.png)
***

## License

This project is under the VIT license.
